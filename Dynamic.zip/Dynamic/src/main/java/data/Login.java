package data;

import org.mindrot.jbcrypt.BCrypt;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/login")
public class Login extends HttpServlet {

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();

		String email = req.getParameter("email");
		String password = req.getParameter("password");

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/shopping_cart_db", "root", "1234");

			String query = "SELECT * FROM users WHERE email = ?";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, email);

			ResultSet rs = pst.executeQuery();

			if (rs.next()) {
				String hashedPassword = rs.getString("password");

				if (BCrypt.checkpw(password, hashedPassword)) {
					HttpSession session = req.getSession();
					session.setAttribute("username", rs.getString("name"));
					session.setAttribute("email", rs.getString("email")); // ✅ this is required
					res.sendRedirect("dashboard.jsp");
				} else {
					out.println("<h3 style='color:red;'>Invalid password</h3><a href='login.html'>Try Again</a>");
				}
			} else {
				out.println("<h3 style='color:red'>User not found</h3><a href='login.html'>Try Again</a>");
			}

		} catch (Exception e) {
			e.printStackTrace();
			out.println("<h3>Error: " + e.getMessage() + "</h3>");
		}
	}
}
