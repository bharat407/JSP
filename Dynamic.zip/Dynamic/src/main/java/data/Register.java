package data;

import org.mindrot.jbcrypt.BCrypt;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/register")
public class Register extends HttpServlet {

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();

		int id = Integer.parseInt(req.getParameter("id"));
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String password = req.getParameter("password");

		// Regex: 6-12 characters, with at least one uppercase, one lowercase, one
		// digit, and one special char
		String passwordRegex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{6,12}$";
		if (!password.matches(passwordRegex)) {
			out.println("<h3 style='color:red; text-align:center;'>"
					+ "Password must be 6-12 characters and include uppercase, lowercase, digit, and special character.</h3>"
					+ "<a href='index.html'>Back to Register Page</a>");
			return;
		}

		String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/shopping_cart_db", "root", "1234");

			// ✅ Check if ID already exists
			PreparedStatement idCheck = con.prepareStatement("SELECT id FROM users WHERE id = ?");
			idCheck.setInt(1, id);
			ResultSet rsId = idCheck.executeQuery();

			if (rsId.next()) {
				out.println("<h3 style='color:red; font-weight:bold; text-align:center;'>ID already registered</h3>"
						+ "" + "<a href='index.html'>Back to Register Page</a>");
				return;
			}

			// ✅ Check if email already exists
			PreparedStatement emailCheck = con.prepareStatement("SELECT email FROM users WHERE email = ?");
			emailCheck.setString(1, email);
			ResultSet rsEmail = emailCheck.executeQuery();

			if (rsEmail.next()) {
				out.println("<h3 style='color:red; font-weight:bold; text-align:center;'>Email already registered</h3>"
						+ "" + "" + "<a href='index.html'>Back to Register Page</a>");
				return;
			}

			// ✅ Proceed with insertion
			String query = "INSERT INTO users (id, name, email, password) VALUES (?, ?, ?, ?)";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, id);
			pst.setString(2, name);
			pst.setString(3, email);
			pst.setString(4, hashedPassword);

			int rows = pst.executeUpdate();

			if (rows > 0) {
				res.sendRedirect("Success.html");
			} else {
				out.println(
						"<h3 style='color:red; font-weight:bold; text-align:center;'>Registration failed. Try again.</h3>"
								+ "" + "" + "<a href='index.html'>Back to Register Page</a>");
			}

		} catch (Exception e) {
			e.printStackTrace();
			out.println("<h3 style='color:red; font-weight:bold; text-align:center;'>Internal Error: " + e.getMessage()
					+ "</h3>");
		}
	}
}
