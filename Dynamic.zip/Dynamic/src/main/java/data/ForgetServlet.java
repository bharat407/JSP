package data;

import java.io.IOException;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/forget")
public class ForgetServlet extends HttpServlet {
  protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
    res.setContentType("text/html");
    String email = req.getParameter("email");

    try {
      Class.forName("com.mysql.cj.jdbc.Driver");
      Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/shopping_cart_db", "root", "1234");

      PreparedStatement pst = con.prepareStatement("SELECT * FROM users WHERE email = ?");
      pst.setString(1, email);
      ResultSet rs = pst.executeQuery();

      if (rs.next()) {
        HttpSession session = req.getSession();
        session.setAttribute("resetEmail", email);
        session.setAttribute("allowReset", true); // flag for single use
        res.sendRedirect("reset.jsp");
      } else {
        req.getSession().setAttribute("error", "Email not found.");
        res.sendRedirect("forget.jsp");
      }

    } catch (Exception e) {
      e.printStackTrace();
      res.getWriter().println("<h3>Error: " + e.getMessage() + "</h3>");
    }
  }
}
