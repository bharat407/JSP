package data;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;

@WebServlet("/delete")
public class DeleteProduct extends HttpServlet {
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		int id = Integer.parseInt(req.getParameter("id"));

		// ✅ Session check
		HttpSession session = req.getSession(false);
		if (session == null || session.getAttribute("username") == null) {
			res.sendRedirect("login.html");
			return;
		}

		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/shopping_cart_db", "root",
				"1234"); PreparedStatement ps = con.prepareStatement("DELETE FROM products WHERE id=?")) {

			ps.setInt(1, id);
			ps.executeUpdate();
			res.sendRedirect("view");
		} catch (Exception e) {
			e.printStackTrace();
			res.sendRedirect("Error.html");
		}
	}
}
