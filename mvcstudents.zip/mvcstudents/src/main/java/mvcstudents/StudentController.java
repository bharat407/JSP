package mvcstudents;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class StudentController {

	@RequestMapping("/register")
	public String showRegister(Model model) {
		model.addAttribute("student", new Student());

		return "Register";

	}

	@PostMapping("/save")
	public String save(@ModelAttribute("student") Student student) {

		try {
			StudentDAO dao = new StudentDAO();

			dao.saveStudent(student);

		} catch (Exception e) {
			e.printStackTrace();
			return "error";
		}
		return "success";
	}

	@GetMapping("/students")
	public String showAllStudents(Model model) {
		try {
			StudentDAO dao = new StudentDAO();
			List<Student> students = dao.getAllStudents();
			System.out.println("DEBUG: Fetched students: " + students); // Add this line
			model.addAttribute("students", students);
			return "studentsList";
		} catch (Exception e) {
			e.printStackTrace();
			return "error";
		}
	}
}
