package ShoppingCart;

import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/view")
public class ViewProduct extends HttpServlet {
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
		ArrayList<Product> products = new ArrayList<>();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/shopping_cart_db", "root",
					"1234");

			String query = "select * from products";
			PreparedStatement pmt = con.prepareStatement(query);
			ResultSet rs = pmt.executeQuery();

			while (rs.next()) {
				Product p = new Product();
				p.id = rs.getInt(1);
				p.name = rs.getString(2);
				p.description = rs.getString(3);
				p.price = rs.getDouble(4);
				p.stock = rs.getInt(5);
				products.add(p);
			}

			req.setAttribute("products", products); // Changed attribute name to plural
			RequestDispatcher rd = req.getRequestDispatcher("view.jsp");
			rd.forward(req, res);

		} catch (Exception e) {
			res.sendRedirect("Error.html");
			e.printStackTrace();
		}
	}
}