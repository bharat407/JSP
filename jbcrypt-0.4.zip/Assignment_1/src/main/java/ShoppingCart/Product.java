package ShoppingCart;

public class Product {

	public int id;
	public String name;
	public String description;
	public double price;
	public int stock;

}
