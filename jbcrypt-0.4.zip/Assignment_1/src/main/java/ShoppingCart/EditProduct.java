package ShoppingCart;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import javax.servlet.*;

@WebServlet("/edit")
public class EditProduct extends HttpServlet {
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		int id = Integer.parseInt(req.getParameter("id"));

		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/shopping_cart_db", "root", "1234");
			 PreparedStatement ps = con.prepareStatement("SELECT * FROM products WHERE id=?")) {
			
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				Product p = new Product();
				p.id = rs.getInt(1);
				p.name = rs.getString(2);
				p.description = rs.getString(3);
				p.price = rs.getDouble(4);
				p.stock = rs.getInt(5);
				
				req.setAttribute("product", p);
				RequestDispatcher rd = req.getRequestDispatcher("edit.jsp");
				rd.forward(req, res);
			} else {
				res.sendRedirect("Error.html");
			}
		} catch (Exception e) {
			e.printStackTrace();
			res.sendRedirect("Error.html");
		}
	}
}
