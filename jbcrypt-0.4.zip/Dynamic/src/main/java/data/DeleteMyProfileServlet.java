package data;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/deleteMyProfile")
public class DeleteMyProfileServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        HttpSession session = req.getSession(false);

        if (session == null || session.getAttribute("email") == null) {
            res.sendRedirect("login.html");
            return;
        }

        String email = (String) session.getAttribute("email");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/shopping_cart_db", "root", "1234");

            PreparedStatement pst = con.prepareStatement("DELETE FROM users WHERE email = ?");
            pst.setString(1, email);
            int rows = pst.executeUpdate();

            if (rows > 0) {
                session.invalidate(); // logout the user
                res.sendRedirect("login.html");
            } else {
                session.setAttribute("error", "Failed to delete profile.");
                res.sendRedirect("dashboard.jsp");
            }

        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("error", "Error: " + e.getMessage());
            res.sendRedirect("dashboard.jsp");
        }
    }
}
