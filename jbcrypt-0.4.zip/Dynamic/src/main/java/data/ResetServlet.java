package data;

import org.mindrot.jbcrypt.BCrypt;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/reset")
public class ResetServlet extends HttpServlet {
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		String email = req.getParameter("email");
		String newPassword = req.getParameter("newPassword");
		String confirmPassword = req.getParameter("confirmPassword");

		if (!newPassword.equals(confirmPassword)) {
			res.getWriter()
					.println("<h3 style='color:red;'>Passwords do not match</h3><a href='reset.jsp'>Try Again</a>");
			return;
		}


		String passwordRegex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{6,12}$";
		if (!newPassword.matches(passwordRegex)) {
			res.getWriter().println(
					"<h3 style='color:red;'>Password must be 6-12 characters and include uppercase, lowercase, digit, and special character.</h3>");
			return;
		}

		String hashed = BCrypt.hashpw(newPassword, BCrypt.gensalt());

		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/shopping_cart_db", "root",
					"1234");
			PreparedStatement pst = con.prepareStatement("UPDATE users SET password=? WHERE email=?");
			pst.setString(1, hashed);
			pst.setString(2, email);

			int row = pst.executeUpdate();
			if (row > 0) {
				HttpSession session = req.getSession(false);
				if (session != null) {
					session.removeAttribute("resetEmail");
					session.removeAttribute("allowReset");
				}
				res.sendRedirect("login.html");
			} else {
				res.getWriter().println("<h3 style='color:red;'>Error updating password.</h3>");
			}

		} catch (Exception e) {
			e.printStackTrace();
			res.getWriter().println("<h3>Error: " + e.getMessage() + "</h3>");
		}
	}
}
