package data;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;

@WebServlet("/update")
public class UpdateProduct extends HttpServlet {
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		int id = Integer.parseInt(req.getParameter("id"));
		String name = req.getParameter("name");
		String description = req.getParameter("description");
		double price = Double.parseDouble(req.getParameter("price"));
		int stock = Integer.parseInt(req.getParameter("stock"));

		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/shopping_cart_db", "root",
				"1234");
				PreparedStatement ps = con
						.prepareStatement("UPDATE products SET name=?, description=?, price=?, stock=? WHERE id=?")) {

			ps.setString(1, name);
			ps.setString(2, description);
			ps.setDouble(3, price);
			ps.setInt(4, stock);
			ps.setInt(5, id);

			ps.executeUpdate();
			res.sendRedirect("view");
		} catch (Exception e) {
			e.printStackTrace();
			res.sendRedirect("Error.html");
		}
	}
}
