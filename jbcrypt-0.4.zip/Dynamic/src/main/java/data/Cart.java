package data;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;

@WebServlet("/product")
public class Cart extends HttpServlet {
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		res.setContentType("text/html");

		// ✅ Session check
		HttpSession session = req.getSession(false);
		if (session == null || session.getAttribute("username") == null) {
			res.sendRedirect("login.html");
			return;
		}

		try {
			int id = Integer.parseInt(req.getParameter("id"));
			String name = req.getParameter("name");
			String description = req.getParameter("description");
			double price = Double.parseDouble(req.getParameter("price"));
			int stock = Integer.parseInt(req.getParameter("stock"));

			Class.forName("com.mysql.cj.jdbc.Driver");

			try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/shopping_cart_db", "root",
					"1234");
					PreparedStatement pmt = con.prepareStatement(
							"INSERT INTO products (id, name, description, price, stock) VALUES (?, ?, ?, ?, ?)")) {

				pmt.setInt(1, id);
				pmt.setString(2, name);
				pmt.setString(3, description);
				pmt.setDouble(4, price);
				pmt.setInt(5, stock);

				if (pmt.executeUpdate() > 0) {
					res.sendRedirect("Success.html");
				} else {
					res.sendRedirect("Error.html");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			res.sendRedirect("Error.html");
		}
	}
}
